<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Reserva extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reserva', function(Blueprint $table) {
            $table->increments('id');

            $table->timestamp('data');
            $table->integer('usuario_id')->unsigned();
            $table->integer('sala_id')->unsigned();
            $table->string('descricao', 500);

            $table->foreign('usuario_id')->references('id')->on('users');
            $table->foreign('sala_id')->references('id')->on('sala');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        \DB::statement("alter table reserva drop foreign key reserva_usuario_id_foreign");
        Schema::dropIfExists('reserva');
    }
}
