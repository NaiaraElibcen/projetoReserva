<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ViewTest extends TestCase
{

    /**
     * A basic test example.
     *
     * @return void
     */
    public function testExample()
    {
        $this->get('/admin/login')->assertStatus(200);
    }

    private function login()
    {
        $user = new \App\User([
            'id' => 1,
            'name' => 'yish'
        ]);

        $this->actingAs($user);

        $response = $this->post('admin/login', [
            'email' => 'admin@admin.com',
            'password' => 'admin'
        ]);
    }

    public function testSalvarReserva()
    {
        $this->login();

        $response = $this->post('reserva/salvar', [
            'salaId' => 1,
            'data' => '2019-03-26',
            'hora' => '09:00',
            'descricao' => 'teste'
        ]);

        $this->assertEquals(200, $response->getStatusCode());
    }
}
