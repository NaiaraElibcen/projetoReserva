<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="base-url" content="{{ url('/') }}">

    <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('bootstrap-4.3.1-dist/css/bootstrap.min.css') }}" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="{{ asset('css/toastr/toastr.min.css') }}">

    <title>Controle de Reserva</title>

    <style>
        .container .user-info {
            display: inline-block;
            position: relative;
            float: right;
        }

        .container .pointer {
            cursor: pointer;
        }

        .container .pointer.click {
            color: blue;
        }

        .container .pointer.delete {
            color: red;
        }
    </style>

  </head>
<body>
    <div class="container" id="container">

        <modal-detalhe params="
            show: $data.modalDetalhe.show,
            aoSalvar: $data.modalDetalhe.aoSalvar,
            dados: $data.modalDetalhe.dados,
            somenteLeitura: $data.modalDetalhe.somenteLeitura"></modal-detalhe>

        <confirmar-remocao params="
            show: $data.modalConfirmar.show,
            aoConfirmar: $data.modalConfirmar.aoConfirmar"></confirmar-remocao>

        <nav class="navbar navbar-light bg-light">
            <a class="navbar-brand" href="#">Controle de Reserva</a>

            <div class="pull-right user-info">
                <label>Usuário: <label> <strong>{{ \Auth::user()->name }}</strong>
                <a data-bind="click: $data.sair" href="#">Sair</a>
            </div>
        </nav>

        <br>

        <div class="row">
            <div class="col-3">
                <div class="form-group">
                    <label for="data">Data</label>
                    <input data-bind="value: $data.dataFiltrar" type="date" class="form-control" placeholder="Entrar com a Data">
                </div>
            </div>
            <div class="col-3">
                <button data-bind="click: $data.filtrar" style="margin-top: 32px;" type="button" class="btn btn-primary">Consultar</button>
            </div>
        </div>

        <br>

        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Horário</th>
                    <th scope="col">Segunda</th>
                    <th scope="col">Terça</th>
                    <th scope="col">Quarta</th>
                    <th scope="col">Quinta</th>
                    <th scope="col">Sexta</th>
                </tr>
            </thead>
            <tbody>
                <!-- ko foreach: $data.reservas -->
                    <tr>
                        <th scope="row"><!--ko text: $data.hora--><!--/ko--></th>

                        <!-- ko foreach: ['segunda', 'terca', 'quarta', 'quinta', 'sexta'] -->
                            <td>
                                <!-- ko if: $parent[$data].usuario -->
                                    <label data-bind="click: $root.abrirDetalhe.bind($data, $parent[$data])" class="pointer click">Reservado </label> : <!--ko text: $parent[$data].usuario.nome --><!--/ko-->
                                    <!-- ko if: $parent[$data].usuario.dono() && !$root.somenteLeitura() -->
                                        <i data-bind="click: $root.abrirConfirmar.bind($data, $parent[$data])" class="fa fa-trash pointer delete" aria-hidden="true"></i>
                                    <!-- /ko -->
                                <!-- /ko -->

                                <!-- ko if: !$parent[$data].usuario -->
                                    <label data-bind="click: $root.abrirDetalhe.bind($data, $parent[$data])" class="pointer click">Disponível</label>
                                <!-- /ko -->
                            </td>
                        <!-- /ko -->

                    </tr>
                <!-- /ko -->
            </tbody>
        </table>
    </div>

    <!-- scripts  -->
    <script src="{{ asset('js/jquery.min.js') }}"></script>
    <script src="{{ asset('bootstrap-4.3.1-dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/knockout/knockout-min.js') }}"></script>
    <script src="{{ asset('js/reserva/loader-template.js') }}"></script>
    <script src="{{ asset('js/moment/moment.min.js') }}"></script>

    <!-- componentes -->
    <script src="{{ asset('js/toastr/toastr.min.js') }}"></script>
    <script src="{{ asset('js/libraries/hero.js') }}"></script>
    <script src="{{ asset('js/libraries/routes.js') }}"></script>

    <script src="{{ asset('js/reserva/modal-detalhe/script.js') }}"></script>
    <script src="{{ asset('js/reserva/confirmar-remocao/script.js') }}"></script>

    <script src="{{ asset('js/reserva/index.js') }}"></script>
</body>
</html>
