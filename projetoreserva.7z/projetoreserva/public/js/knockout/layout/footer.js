ko.components.register('app-footer', {
    viewModel: function(params) {

    },
    template: [
        '<footer class="main-footer">',
            '<div class="pull-right hidden-xs">',
                '<b>Version</b> 1.0.0',
            '</div>',
            '<strong>Ateliê Maria Modas</strong>',
        '</footer>',
        '<div class="control-sidebar-bg"></div>'].join(' '),
});
