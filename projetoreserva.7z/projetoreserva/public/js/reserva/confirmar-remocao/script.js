ko.components.register('confirmar-remocao', {
    viewModel: {
        createViewModel: function (params, componentInfo) {

            var ViewModel = function(params, componentInfo){
                var self = this;

                self.element = componentInfo.element.firstElementChild;
                self.dados = params.dados;

                self.cancelar = function(){
                    params.show(false);
                };

                self.confirmar = function(){
                    self.cancelar();
                    params.aoConfirmar(self, params);
                };

                params.show.subscribe(function (new_value) {
                    $(self.element).modal(new_value ? 'show' : 'hide');
                });

                $(self.element).on('hide.bs.modal', function (event) {
                    params.show(false);
                });
            };
        
            return new ViewModel(params, componentInfo);
        }
    },

    template: { fromUrl: 'js/reserva/confirmar-remocao/template.html', maxCacheAge: 1234 },
});