var Usuario = function(id, nome, dono){
    var self = this;

    self.id = ko.observable(id);
    self.nome = ko.observable(nome);
    self.dono = ko.observable(dono);
};

var DiaReserva = function(id, usuario, dia, descricao){
    var self = this;

    self.id = ko.observable(id);
    self.usuario = usuario;
    self.dia = ko.observable(dia);
    self.descricao = ko.observable(descricao);
    self.parent = null; //item reserva
};

var ItemReserva  = function(dias, hora){
    var self = this;

    self.hora = ko.observable(hora);

    ['segunda', 'terca', 'quarta', 'quinta', 'sexta'].forEach(function(dia){
        self[dia] = dias[dia];
        self[dia].parent = self;
    });
};

var AppViewModel = function(){
    var self = this;

    self.salaId = 1;

    self.modalDetalhe = {
        show: ko.observable(false),
        dados: {
            hora: ko.observable(),
            data: ko.observable(),
            descricao: ko.observable(),
        },
        aoSalvar: function(modal, params){
            self.salvarDados({
                salaId: self.salaId,
                data: params.dados.data(),
                hora: params.dados.hora(),
                descricao: params.dados.descricao(),
            }, modal);
        },
        somenteLeitura: ko.observable(true)
    };

    self.mostrarMensagemErro = function(lista){
        if (Array.isArray(lista)){
            _hero.toastr.error(lista.join('<br>'));
            return;
        }

        var message = "";
        Object.keys(lista).forEach(function(key){
            message += lista[key][0] + '<br>';
        });

        _hero.toastr.error(message);
    };

    self.salvarDados = function(request, modal){
        _hero.ajax()
        .url(_hero.routes.find('reserva.salvar'))
        .verb("POST")
        .payload(request)
        .then(function(data) {
            if (data.status == _hero.STATUS_RESPONSE.SUCCESS){
                modal.fechar();
                self.buscarReservas();
                _hero.toastr.success('Reserva Criada/Alterada com sucesso!!');
            } else {
                self.mostrarMensagemErro(data.message);
            }
        })
        .fail(function(data) {
            var response = data.responseJSON.response;

            self.mostrarMensagemErro(response);
        }).execute();
    };

    self.removeReserva = function(id){
        _hero.ajax()
        .url(_hero.routes.find('reserva.deletar', {id: id}))
        .verb("DELETE")
        .then(function(data) {
            if (data.status == _hero.STATUS_RESPONSE.SUCCESS){
                self.buscarReservas();
                _hero.toastr.success('Reserva Removida com sucesso!!');
            } else {
                self.mostrarMensagemErro(data.message);
            }
        })
        .fail(function(data) {
            var response = data.responseJSON.response;
            self.mostrarMensagemErro(response);
        }).execute();
    };

    self.modalConfirmar = {
        remover: null,
        show: ko.observable(false),
        aoConfirmar: function(modal, params){
            self.removeReserva(self.modalConfirmar.remover.id());
        },
    }

    self.abrirDetalhe = function(diaReserva){
        self.modalDetalhe.dados.hora(diaReserva.parent.hora());
        self.modalDetalhe.dados.data(diaReserva.dia());
        self.modalDetalhe.dados.descricao(diaReserva.descricao());

        if (diaReserva.usuario){
            self.modalDetalhe.somenteLeitura(self.somenteLeitura() || !diaReserva.usuario.dono());
        } else {
            self.modalDetalhe.somenteLeitura(self.somenteLeitura());
        }

        self.modalDetalhe.show(true);
    };

    self.abrirConfirmar = function(itemReserva){
        self.modalConfirmar.remover = itemReserva;
        self.modalConfirmar.show(true);
    };

    self.dataFiltrar = ko.observable(moment().format('YYYY-MM-DD'));

    self.filtrar = function(){
        self.buscarReservas();
    };

    self.sair = function(){
        _hero.routes.redirect("admin.logout.user");
    };

    self.diasSemana = [
        'segunda',
        'terca',
        'quarta',
        'quinta',
        'sexta'
    ];

    self.reservas = ko.observableArray();
    self.somenteLeitura = ko.observable(true);

    self.buscarReservas = function(){
        _hero.ajax()
        .url(_hero.routes.find('reserva.detalhe', {
            salaId: self.salaId,
            data: self.dataFiltrar()
        }))
        .verb("GET")
        .then(function(data) {
            if (data.status == _hero.STATUS_RESPONSE.SUCCESS){

                self.reservas.removeAll();

                for (var hora = 6; hora <= 23; hora++) {
                    var dias = data.response.dados.filter(function(reserva){
                        return reserva.hora == hora.toString().padStart(2, "0") + ':00:00';
                    });

                    dias.sort(function(a, b) {
                        return a.dia_semana - b.dia_semana;
                    });

                    var diasReduce = dias.reduce(function(current, item){
                        current[item.dia_semana] = item;
                        return current;
                    }, []);

                    var diasItemReserva = {};

                    for (var dia = 1; dia <= 5; dia++) {
                        if (diasReduce[dia]){
                            var _id = diasReduce[dia].id;
                            var _usuario = new Usuario(diasReduce[dia].usuario.id, diasReduce[dia].usuario.nome, diasReduce[dia].usuario.dono);
                            var _data = diasReduce[dia].data;
                            var _descricao = diasReduce[dia].descricao;
                        } else {
                            var _id = null;
                            var _usuario = null;
                            var _data = data.response.dias[dia - 1];
                            var _descricao = null;
                        }

                        diasItemReserva[self.diasSemana[dia - 1]] = new DiaReserva(_id, _usuario, _data, _descricao);
                    }

                    self.reservas.push(new ItemReserva(diasItemReserva, hora.toString().padStart(2, "0") + ':00'));
                }

                self.somenteLeitura(data.response.somente_leitura);

            } else {
                _hero.toastr.error('Erro ao realizar a busca');
            }
        })
        .fail(function(data) {
            _hero.toastr.error('Erro ao realizar a busca');
        }).execute();
    };

    self.buscarReservas();
};

ko.applyBindings(new AppViewModel(), document.getElementById('container'));