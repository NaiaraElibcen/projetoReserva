ko.components.register('modal-detalhe', {
    viewModel: {
        createViewModel: function (params, componentInfo) {

            var ViewModel = function(params, componentInfo){
                var self = this;

                self.element = componentInfo.element.firstElementChild;
                self.dados = params.dados;
                self.somenteLeitura = params.somenteLeitura;

                self.fechar = function(){
                    params.show(false);
                };

                self.salvar = function(){
                    params.aoSalvar(self, params);
                };

                params.show.subscribe(function (new_value) {
                    $(self.element).modal(new_value ? 'show' : 'hide');
                });

                $(self.element).on('hide.bs.modal', function (event) {
                    params.show(false);
                });
            };
        
            return new ViewModel(params, componentInfo);
        }
    },

    template: { fromUrl: 'js/reserva/modal-detalhe/template.html', maxCacheAge: 1234 },
});