<?php

use Illuminate\Http\Request;
use App\Http\Responses\BaseResponse;

Route::get('/routes', function(){
    $routes = [];

    foreach (Route::getRoutes()->getIterator() as $route){
        if ($route->getName()){
            $routes[] = [
                'name' => $route->getName(),
                'url' => url($route->uri()),
                'verb' => $route->methods()[0],
            ];
        }
    }

    return BaseResponse::successData($routes);
});

//. ADMIN .//
Route::group([
    'namespace' => 'Admin',
    'as' => 'admin.',
    'prefix' => 'admin'
], function(){
    Route::get('/login', 'AdminController@index')->middleware('redirectIfAuth')->name('login.index');
    Route::post('/login', 'AdminController@login')->name('login.user');
    Route::get('/logout', 'AdminController@logout')->name('logout.user');
});

// . REDIRECT .//
Route::get('/', function(){
    return redirect()->route('reserva.index');
});

Route::group([
    'namespace' => 'Reserva',
    'as' => 'reserva.',
    'prefix' => 'reserva',
    'middleware' => 'redirectIfNotAuth'
], function(){

    Route::get('/', 'ReservaController@home')->name('index');
    Route::get('/detalhe/{salaId}/{data}', 'ReservaController@detalhe')->name('detalhe');
    Route::post('/salvar', 'ReservaController@salvar')->name('salvar');
    Route::delete('/{id}', 'ReservaController@deletar')->name('deletar');

});