<?php

namespace App\Http\Requests\Reserva;

use App\Http\Requests\BaseRequest;

class SalvarReservaRequest extends BaseRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'salaId' => 'required|exists:sala,id',
            'data' => 'required',
            'hora' => 'required',
            'descricao' => 'required',
        ];
    }
}
