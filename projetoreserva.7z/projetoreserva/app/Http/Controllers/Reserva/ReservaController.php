<?php
namespace App\Http\Controllers\Reserva;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Reserva\SalvarReservaRequest;
use App\Services\Reserva\ReservaService;
use Auth;

class ReservaController extends BaseController
{

    private $service;

    public function __construct(ReservaService $service)
    {
        $this->service = $service;
    }

    public function home()
    {
        return view('reserva.home');
    }

    public function detalhe($salaId, $data)
    {
        $userId = Auth::id();
        $response = $this->service->detalhe($userId, $salaId, $data);

        return $this->formatResponse($response);
    }

    public function salvar(SalvarReservaRequest $request)
    {
        $request->merge(['userId' => Auth::id()]);

        $response = $this->service->salvar($request->all());

        return $this->formatResponse($response);
    }

    public function deletar($reservaId)
    {
        $userId = Auth::id();

        $response = $this->service->deletar($userId, $reservaId);

        return $this->formatResponse($response);
    }
}
