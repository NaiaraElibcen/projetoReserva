<?php

namespace App\Models\Reserva;

use App\Models\BaseModel;

use Illuminate\Database\Eloquent\Model;

class Sala extends BaseModel
{
    public $table = "sala";
    public $primaryKey = "id";

    public $timestamps = false;
}
