<?php

namespace App\Models\Reserva;

use App\Models\BaseModel;

use Illuminate\Database\Eloquent\Model;

class Reserva extends BaseModel
{
    public $table = "reserva";
    public $primaryKey = "id";

    public $timestamps = false;

    public function user() 
    {
        return $this->belongsTo('App\User', 'usuario_id', 'id');
    }
}
