<?php

namespace App\Services\Reserva;

use App\Services\BaseService;
use App\Services\Library\ServiceData;
use App\Models\Reserva\Sala;
use App\Models\Reserva\Reserva;
use DateTime;
use Carbon\Carbon;

class ReservaService extends BaseService
{

    public function salvar(array $params)
    {
        return $this->transaction(function() use ($params) {
            $response = new ServiceData;

            if (!$this->isCurrentWeek($params['data'])){
                return $response->setErrors(['Reserva fora do Intervalo']);
            }

            $data_hora = $params['data'] . ' ' . $params['hora'];

            if ($reservaSalva = $this->reservaComData($data_hora, $params['salaId'])){
                if ($reservaSalva->usuario_id != $params['userId']){
                    return $response->setErrors(['Um outro Usuário já reservou esta sala']);
                }

                $reservaSalva->delete();
            }

            $reserva = new Reserva;
            $reserva->data = $data_hora;
            $reserva->usuario_id = $params['userId'];
            $reserva->sala_id = $params['salaId'];
            $reserva->descricao = $params['descricao'];
            $reserva->save();

            return $response->setData($reserva);
        });
    }

    private function reservaComData($data_hora, $sala_id)
    {
        return Reserva::where('sala_id', $sala_id)->where('data', $data_hora)->first();
    }

    public function detalhe($userId, $salaId, $data)
    {
        return $this->holdMistake(function() use ($userId, $salaId, $data) {
            $response = new ServiceData;

            $days = $this->getDaysWeek($data);

            $reservas = Reserva::where('sala_id', $salaId)->with('user')
                ->where('data', '>=', reset($days) . ' 00:00:00')
                ->where('data', '<=', end($days) . ' 23:59:59')
            ->get();

            $custom_response = $reservas->map(function($reserva) use ($userId){

                $dataCarbon = Carbon::createFromFormat('Y-m-d H:i:s', $reserva->data);

                return [
                    'id' => $reserva->id,
                    'data' => $dataCarbon->format('Y-m-d'),
                    'hora' => $dataCarbon->format('H:i:s'),
                    'dia_semana' => $dataCarbon->dayOfWeek,
                    'descricao' => $reserva->descricao,
                    'usuario' => [
                        'id' => $userId,
                        'dono' => ($userId == $reserva->usuario_id),
                        'nome' => $reserva->user->name,
                    ],
                ];
            });

            return $response->setData([
                'dias' => $days,
                'somente_leitura' => !$this->isCurrentWeek($data),
                'dados' => $custom_response,
            ]);
        });
    }

    public function deletar($userId, $reservaId)
    {
        return $this->holdMistake(function() use ($userId, $reservaId) {
            $response = new ServiceData;

            $reserva = Reserva::find($reservaId);

            if (!$reserva){
                return $response->setErrors(['Reserva não encontrada']);
            }

            if ($reserva->usuario_id != $userId){
                return $response->setErrors(['Você não é o criador da Reserva']);
            }

            $reserva->delete();

            return $response;
        });
    }

    private function isCurrentWeek(string $dateCompare)
    {
        return (new DateTime($dateCompare))->format("W") == (new DateTime())->format("W");
    }

    private function getDaysWeek(string $dateStr)
    {
        $date = new DateTime($dateStr);
        $week = $date->format("W");
        $year = $date->format("Y");

        $results = [];

        for($day = 1; $day <= 5; $day++) {
            $results[] = date('Y-m-d', strtotime($year . "W". $week . $day));
        }

        return $results;
    }
}
